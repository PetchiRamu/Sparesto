

"use client";

import Link from "next/link";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export default function Header() {
  const [open, setOpen] = useState(false);

  const menuItems = [
    { name: "Home", href: "/" },
    { name: "About Us", href: "/about" },
    { name: "Services", href: "/services" },
    { name: "Enquiry", href: "/enquiry" },
    { name: "Contact Us", href: "/contact" },
  ];

  return (
    <header className="w-full bg-[#EEF4F4] border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-[1400px] mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-[90px]">

          {/* Logo */}
          <Link href="/" className="flex-shrink-0">
            <img
              src="/logo.png"
              alt="Logo"
              className="h-14 md:h-16 w-auto object-contain"
            />
          </Link>

          {/* Desktop Menu */}
          <nav className="hidden lg:flex items-center gap-12">
            {menuItems.map((item, index) => (
              <Link
                key={index}
                href={item.href}
                className={`text-[18px] font-medium transition-colors ${
                  index === 0
                    ? "text-[#006B68] border-b-[3px] border-[#006B68] pb-2"
                    : "text-gray-700 hover:text-[#006B68]"
                }`}
              >
                {item.name}
              </Link>
            ))}
          </nav>

          {/* Right Side */}
          <div className="hidden lg:flex items-center gap-8">
            <Link
              href="/login"
              className="bg-[#006B68] text-white px-8 py-3 rounded-xl font-semibold hover:bg-[#005552] transition"
            >
              Login
            </Link>

            <Link
              href="/help"
              className="text-gray-700 font-medium hover:text-[#006B68]"
            >
              Help
            </Link>
          </div>

          {/* Mobile Toggle */}
          <button
            className="lg:hidden"
            onClick={() => setOpen(!open)}
          >
            {open ? (
              <X className="w-7 h-7" />
            ) : (
              <Menu className="w-7 h-7" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {open && (
        <div className="lg:hidden bg-[#EEF4F4] border-t">
          <div className="px-6 py-5 flex flex-col gap-5">

            {menuItems.map((item, index) => (
              <Link
                key={index}
                href={item.href}
                onClick={() => setOpen(false)}
                className="text-gray-700 text-lg font-medium"
              >
                {item.name}
              </Link>
            ))}

            <div className="border-t pt-5 flex flex-col gap-4">
              <Link
                href="/login"
                className="bg-[#006B68] text-white text-center py-3 rounded-xl font-semibold"
              >
                Login
              </Link>

              <Link
                href="/help"
                className="text-center text-gray-700 font-medium"
              >
                Help
              </Link>
            </div>

          </div>
        </div>
      )}
    </header>
  );
}
