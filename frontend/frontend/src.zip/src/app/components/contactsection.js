"use client";

import {
    MapPin,
    Phone,
    Mail,
    Send,
} from "lucide-react";

export default function ContactSection() {

    const services = [
        "Strategic Sourcing & Procurement",
        "Technical Manpower Supply",
        "E-Auction Solutions",
        "Component Testing & Servicing",
    ];

    return (

        <section className="bg-[#EDF6F5] py-20">

            <div className="max-w-7xl mx-auto px-4">


                {/* Header */}

                <div className="text-center mb-14">

                    <span className="inline-block px-5 py-2 rounded-full bg-[#D8F0EE] text-[#0F766E] text-sm font-medium">

                        CONTACT US

                    </span>

                    <h2 className="text-5xl font-bold text-slate-900 mt-4">

                        Let's Work Together

                    </h2>

                    <p className="mt-5 text-gray-600 max-w-2xl mx-auto">

                        Reach out for procurement queries,

                        partnership opportunities,

                        or to get a custom quote

                        for your requirements.

                    </p>

                </div>



                <div className="grid lg:grid-cols-2 gap-10">


                    {/* Left Side */}

                    <div>


                        <h3 className="text-xl font-semibold text-[#0F766E] mb-10">

                            Sparesto Solutions Pvt. Ltd.

                        </h3>



                        <div className="space-y-8">


                            <div className="flex gap-4">

                                <div className="w-12 h-12 rounded-xl border border-cyan-200 flex items-center justify-center">

                                    <MapPin className="w-5 h-5 text-cyan-500" />

                                </div>

                                <div>

                                    <h4 className="font-medium">

                                        Address

                                    </h4>

                                    <p className="text-gray-600">

                                        110/A3-6,

                                        Valliyoor,

                                        Radhapuram Tirunelveli – 627111

                                        Tamil Nadu, India.

                                    </p>

                                </div>

                            </div>



                            <div className="flex gap-4">

                                <div className="w-12 h-12 rounded-xl border border-cyan-200 flex items-center justify-center">

                                    <Phone className="w-5 h-5 text-cyan-500" />

                                </div>

                                <div>

                                    <h4 className="font-medium">

                                        Phone

                                    </h4>

                                    <p className="text-gray-600">

                                        +91 73580 05843

                                    </p>

                                </div>

                            </div>



                            <div className="flex gap-4">

                                <div className="w-12 h-12 rounded-xl border border-cyan-200 flex items-center justify-center">

                                    <Mail className="w-5 h-5 text-cyan-500" />

                                </div>

                                <div>

                                    <h4 className="font-medium">

                                        Email

                                    </h4>

                                    <p className="text-gray-600">

                                        purchase@sparesto.com

                                    </p>

                                </div>

                            </div>


                        </div>




                        <div className="mt-12 bg-gradient-to-br from-white to-cyan-100 rounded-3xl p-10 text-center">

                            <div className="mx-auto w-14 h-14 rounded-full bg-white shadow-lg flex items-center justify-center mb-6">

                                <MapPin className="text-cyan-500" />

                            </div>


                            <h4 className="text-[#0F766E] text-lg font-medium">

                                Our Presence

                            </h4>


                            <p className="text-gray-600 mt-3">

                                Tirunelveli,

                                Tamil Nadu

                                <br />

                                Radhapuram, India

                            </p>

                        </div>



                    </div>



                    {/* Right Side */}

                    <div className="bg-white rounded-3xl p-10 shadow-sm border border-gray-100">


                        <h3 className="text-lg font-medium mb-8">

                            Send us a Message

                        </h3>


                        <form className="space-y-6">


                            <div className="grid md:grid-cols-2 gap-5">


                                <input

                                    type="text"

                                    placeholder="Your Name"

                                    className="h-12 rounded-xl border border-cyan-100 bg-[#EDF6F5] px-4 outline-none"

                                />



                                <input

                                    type="text"

                                    placeholder="Company Name"

                                    className="h-12 rounded-xl border border-cyan-100 bg-[#EDF6F5] px-4 outline-none"

                                />



                                <input

                                    type="email"

                                    placeholder="email@address.com"

                                    className="h-12 rounded-xl border border-cyan-100 bg-[#EDF6F5] px-4 outline-none"

                                />



                                <input

                                    type="text"

                                    placeholder="+91 XXXXX XXXXX"

                                    className="h-12 rounded-xl border border-cyan-100 bg-[#EDF6F5] px-4 outline-none"

                                />


                            </div>




                            <select

                                className="w-full h-12 rounded-xl border border-cyan-100 bg-[#EDF6F5] px-4 outline-none"

                            >

                                {services.map((service, index) => (

                                    <option key={index}>

                                        {service}

                                    </option>

                                ))}

                            </select>



                            <textarea

                                rows="5"

                                placeholder="How can we help you?"

                                className="w-full rounded-xl border border-cyan-100 bg-[#EDF6F5] px-4 py-3 outline-none"

                            />



                            <button

                                className="w-full h-12 rounded-xl bg-gradient-to-r from-[#0F766E] to-cyan-400 text-white font-semibold flex items-center justify-center gap-2"

                            >

                                Send Message

                                <Send size={18} />

                            </button>



                        </form>


                    </div>


                </div>


            </div>

        </section>

    );

}