// "use client";

// import React from "react";

// export default function Footer() {
//   const footerData = [
//     { 
//       title: "Company", 
//       items: ["About Us", "Careers", "Press"] 
//     },
//     { 
//       title: "Resources", 
//       items: ["Blog", "Catalogs", "Support Center"] 
//     },
//     { 
//       title: "Legal", 
//       items: [
//         { label: "General Terms Of Sale", href: "/Sparesto design guide.pdf" },
//         { label: "Refurbishment Terms", href: "/Sparesto design guide.pdf" },
//         { label: "Supplier Code Of Conduct", href: "/Sparesto design guide.pdf" },
//         { label: "Code Of Conduct", href: "/Sparesto design guide.pdf" },
//         { label: "Privacy Policy", href: "/Sparesto design guide.pdf" },
//         { label: "Sustainability Policy", href: "/Sparesto design guide.pdf" },
//       ] 
//     },
//     { 
//       title: "Contact", 
//       items: ["Contact Sales", "Get Support"] 
//     },
//   ];

//   return (
//     <footer className="w-full bg-[#0d1724] border-t border-gray-800 py-12">
//       <div className="max-w-7xl mx-auto px-6 lg:px-8">
        
//         {/* Responsive Grid Layout */}
//         <div className="flex flex-wrap justify-between gap-10">
//           {footerData.map((section, i) => (
//             <div key={i} className="min-w-[140px] flex-1 md:flex-none">
//               <h3 className="font-semibold text-white text-base md:text-xl mb-4">
//                 {section.title}
//               </h3>
//               <ul className="text-white opacity-80 space-y-3 text-sm md:text-base">
//                 {section.items.map((item, idx) => {
//                   // Determine if the item is a PDF link object or a simple string
//                   const isLink = typeof item === "object";
//                   const content = isLink ? item.label : item;

//                   return (
//                     <li 
//                       key={idx} 
//                       className="hover:underline hover:opacity-100 cursor-pointer transition-all duration-200"
//                     >
//                       {isLink ? (
//                         <a 
//                           href={item.href} 
//                           target="_blank" 
//                           rel="noopener noreferrer"
//                           className="focus:outline-none"
//                         >
//                           {content}
//                         </a>
//                       ) : (
//                         <span>{content}</span>
//                       )}
//                     </li>
//                   );
//                 })}
//               </ul>
//             </div>
//           ))}
//         </div>

//         {/* Bottom Section */}
//         <div className="border-t border-gray-700 mt-12 pt-8">
//           <p className="text-center text-white opacity-60 text-sm md:text-base">
//             © {new Date().getFullYear()} Company Name. All rights reserved.
//           </p>
//         </div>
//       </div>
//     </footer>
//   );
// }

"use client";

import Link from "next/link";
import {
  Facebook,
  Instagram,
  Linkedin,
  Twitter,
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[#EDF6F5] py-14">
      <div className="max-w-7xl mx-auto px-6">

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">

          {/* Column 1 */}
          <div>
            <h3 className="text-xl font-bold text-slate-900 mb-5">
              Sparesto Solutions
            </h3>

            <p className="text-gray-600 leading-7 mb-6">
              Your trusted partner for renewable procurement
              and tailored solutions delivering quality
              products and exceptional service.
            </p>

            {/* Social Icons */}

            <div className="flex gap-3">

              <a
                href="#"
                className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center hover:bg-[#0F766E] hover:text-white transition"
              >
                <Facebook size={18} />
              </a>

              <a
                href="#"
                className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center hover:bg-[#0F766E] hover:text-white transition"
              >
                <Instagram size={18} />
              </a>

              <a
                href="#"
                className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center hover:bg-[#0F766E] hover:text-white transition"
              >
                <Linkedin size={18} />
              </a>

              <a
                href="#"
                className="w-10 h-10 rounded-full bg-white shadow flex items-center justify-center hover:bg-[#0F766E] hover:text-white transition"
              >
                <Twitter size={18} />
              </a>

            </div>

          </div>


          {/* Column 2 */}

          <div>

            <h3 className="text-[#0F766E] font-semibold uppercase mb-5">
              Quick Links
            </h3>

            <ul className="space-y-3 text-gray-600">

              <li>
                <Link href="/products">
                  Products
                </Link>
              </li>

              <li>
                <Link href="/e-auction">
                  E-Auction
                </Link>
              </li>

              <li>
                <Link href="/manpower">
                  Manpower Supply
                </Link>
              </li>

            </ul>

          </div>



          {/* Column 3 */}

          <div>

            <h3 className="text-[#0F766E] font-semibold uppercase mb-5">
              Support
            </h3>

            <ul className="space-y-3 text-gray-600">

              <li>
                <Link href="#">
                  Spare Parts Services
                </Link>
              </li>

              <li>
                <Link href="#">
                  Privacy Policy
                </Link>
              </li>

              <li>
                <Link href="#">
                  Terms Of Service
                </Link>
              </li>

            </ul>

          </div>



          {/* Column 4 */}

          <div>

            <h3 className="text-[#0F766E] font-semibold uppercase mb-5">
              Newsletter
            </h3>

            <p className="text-gray-600 mb-5">
              Get the latest availability updates directly.
            </p>


            <div className="flex">

              <input
                type="email"
                placeholder="Email address"
                className="flex-1 h-11 px-4 rounded-l-lg border border-gray-200 outline-none"
              />

              <button
                className="bg-[#0F766E] text-white px-5 rounded-r-lg"
              >
                Join
              </button>

            </div>

          </div>


        </div>


        {/* Bottom Line */}

        <div className="border-t border-gray-200 mt-12 pt-6 text-center text-gray-500">

          © 2026 Sparesto Solutions Pvt Ltd.
          All Rights Reserved.

        </div>

      </div>
    </footer>
  );
}