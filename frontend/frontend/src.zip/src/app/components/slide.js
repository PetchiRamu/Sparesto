"use client";

import Image from "next/image";
import { Swiper, SwiperSlide } from "swiper/react";
import { Autoplay } from "swiper/modules";

import "swiper/css";

const logos = [
  "/logos/logo1.png",
  "/logos/logo2.png",
  "/logos/logo3.png",
  "/logos/logo4.png",
  "/logos/logo5.png",
  "/logos/logo6.png",
];

export default function TrustedClients() {
  return (
    <section className="bg-[#EDF6F5] py-16">
      <div className="max-w-7xl mx-auto px-4">

        {/* Badge */}
        <div className="flex justify-center">
          <span className="bg-[#D8F0EE] text-[#0F766E] text-sm font-medium px-4 py-2 rounded-full">
            Trusted Clients
          </span>
        </div>

        {/* Heading */}
        <h2 className="text-center text-4xl md:text-5xl font-bold text-slate-900 mt-4 mb-14">
          Trusted Clients
        </h2>

        {/* Logo Carousel */}
        <Swiper
          modules={[Autoplay]}
          loop={true}
          spaceBetween={30}
          autoplay={{
            delay: 2000,
            disableOnInteraction: false,
          }}
          breakpoints={{
            0: {
              slidesPerView: 2,
            },
            768: {
              slidesPerView: 3,
            },
            1024: {
              slidesPerView: 5,
            },
          }}
        >
          {logos.map((logo, index) => (
            <SwiperSlide key={index}>

              <div className="h-28 bg-white rounded-lg shadow-sm flex items-center justify-center">

                <Image
                  src={logo}
                  alt="client-logo"
                  width={180}
                  height={80}
                  className="object-contain"
                />

              </div>

            </SwiperSlide>
          ))}
        </Swiper>

      </div>
    </section>
  );
}