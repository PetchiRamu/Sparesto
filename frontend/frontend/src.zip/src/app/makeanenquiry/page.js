'use client';
import React, { useState } from 'react';
// import { enquiryForm } from '../services/apiService'; 
import { enquiryForm } from '../apiservices/apiServices';

export default function EnquiryPage() {
  // 1. State for Form Data
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    companyName: "",
    contactNumber: "",
    productCode: "",
    productName: "",
    reason: "General Support",
    message: ""
  });

  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false); // Track submission status

  // 2. Handle Input Changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  // 3. Handle Submit
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await enquiryForm(formData);
      // Change state to show the "Success Page"
      setSubmitted(true);
      // Reset form data for future use
      setFormData({
        name: "", email: "", companyName: "", contactNumber: "",
        productCode: "", productName: "", reason: "General Support", message: ""
      });
    } catch (error) {
      alert("Error: " + error.message);
    } finally {
      setLoading(false);
    }
  };

  /**
   * SUCCESS PAGE VIEW
   * This part will render as a "New Page" once submitted is true
   */
  if (submitted) {
    return (
      <main className="min-h-screen w-full flex flex-col items-center justify-center bg-white p-6">
        <div className="text-center max-w-2xl animate-in fade-in zoom-in duration-500">
          <div className="mb-8 flex justify-center">
            <div className="w-24 h-24 bg-[#AEEBE7] rounded-full flex items-center justify-center text-[#1F7F7A]">
              <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-[#1F7F7A] mb-6">
            Enquiry Received!
          </h1>
          
          <p className="text-xl text-gray-600 mb-10 leading-relaxed">
            Thank you for reaching out. Your details have been successfully submitted. 
            Our team will review your request and contact you at <span className="font-bold text-[#1F7F7A]">{formData.email}</span> shortly.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => setSubmitted(false)}
              className="px-10 py-4 bg-[#1F7F7A] text-white font-bold rounded-full hover:bg-[#155E5A] transition-all shadow-lg shadow-[#1F7F7A]/20"
            >
              Back to Form
            </button>
            <button 
              onClick={() => window.location.href = '/'} 
              className="px-10 py-4 border-2 border-[#1F7F7A] text-[#1F7F7A] font-bold rounded-full hover:bg-[#AEEBE7]/30 transition-all"
            >
              Go to Home
            </button>
          </div>
        </div>
      </main>
    );
  }

  // DEFAULT FORM VIEW
  return (
    <main className="min-h-screen grid grid-cols-1 lg:grid-cols-12 bg-white">
      
      {/* LEFT SIDE: Branding & Info */}
      <div className="lg:col-span-5 bg-[#1F7F7A] p-8 md:p-16 flex flex-col justify-between text-white">
        <div>
          <h2 className="text-sm uppercase tracking-[0.2em] mb-4 opacity-80">Contact Us</h2>
          <h1 className="text-5xl font-bold mb-6 leading-tight">
            Let’s build something <span className="text-[#AEEBE7]">significant</span> together.
          </h1>
          <p className="text-[#AEEBE7]/80 text-lg max-w-md">
            Whether you have a specific project in mind or just want to explore the possibilities, our team is ready to help.
          </p>
        </div>

        <div className="space-y-6 mt-12">   
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-full bg-[#155E5A] flex items-center justify-center">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
              </svg>
            </div>
            <div>
              <p className="text-xs uppercase opacity-60">Email us</p>
              <p className="font-semibold text-lg text-white">salessparesto@gmail.com</p>
            </div>
          </div>
        </div>
      </div>

      {/* RIGHT SIDE: The Form */}
      <div className="lg:col-span-7 bg-[#AEEBE7] p-8 md:p-16 flex items-center">
        <div className="w-full max-w-xl mx-auto">
          <form className="space-y-6" onSubmit={handleSubmit}>
            {/* Name & Email Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-black uppercase text-[#1E2A2A]">Name</label>
                <input 
                  type="text"
                  name="name"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full border-b-2 border-[#D6ECEA] focus:border-[#1F7F7A] px-0 py-3 text-[#1E2A2A] outline-none transition-all bg-transparent"
                  placeholder="Your name"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black uppercase text-[#1E2A2A]">Email</label>
                <input 
                  type="email"
                  name="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full border-b-2 border-[#D6ECEA] focus:border-[#1F7F7A] px-0 py-3 text-[#1E2A2A] outline-none transition-all bg-transparent"
                  placeholder="Your email"
                />
              </div>
            </div>

            {/* Company & Contact Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-black uppercase text-[#1E2A2A]">Company Name</label>
                <input 
                  type="text"
                  name="companyName"
                  value={formData.companyName}
                  onChange={handleChange}
                  className="w-full border-b-2 border-[#D6ECEA] focus:border-[#1F7F7A] px-0 py-3 text-[#1E2A2A] outline-none transition-all bg-transparent"
                  placeholder="Company name"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black uppercase text-[#1E2A2A]">Contact Number</label>
                <input 
                  type="tel"
                  name="contactNumber"
                  value={formData.contactNumber}
                  onChange={handleChange}
                  className="w-full border-b-2 border-[#D6ECEA] focus:border-[#1F7F7A] px-0 py-3 text-[#1E2A2A] outline-none transition-all bg-transparent"
                  placeholder="Phone number"
                />
              </div>
            </div>

            {/* Product Details Row */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-xs font-black uppercase text-[#1E2A2A]">Product Code</label>
                <input 
                  type="text"
                  name="productCode"
                  value={formData.productCode}
                  onChange={handleChange}
                  className="w-full border-b-2 border-[#D6ECEA] focus:border-[#1F7F7A] px-0 py-3 text-[#1E2A2A] outline-none transition-all bg-transparent"
                  placeholder="SKU or Item Code"
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-black uppercase text-[#1E2A2A]">Product Name</label>
                <input 
                  type="text"
                  name="productName"
                  value={formData.productName}
                  onChange={handleChange}
                  className="w-full border-b-2 border-[#D6ECEA] focus:border-[#1F7F7A] px-0 py-3 text-[#1E2A2A] outline-none transition-all bg-transparent"
                  placeholder="Product name"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black uppercase text-[#1E2A2A]">Reason for Enquiry</label>
              <div className="relative">
                <select 
                  name="reason"
                  value={formData.reason}
                  onChange={handleChange}
                  className="w-full border-b-2 border-[#D6ECEA] focus:border-[#1F7F7A] py-3 text-[#1E2A2A] outline-none transition-all bg-transparent appearance-none"
                >
                  <option value="General Support">General Support</option>
                  <option value="Suggestions">Suggestions</option>
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-[#1F7F7A]">
                  <svg className="h-4 w-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"/></svg>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-xs font-black uppercase text-[#1E2A2A]">Message</label>
              <textarea 
                rows={3}
                name="message"
                required
                value={formData.message}
                onChange={handleChange}
                className="w-full border-b-2 border-[#D6ECEA] focus:border-[#1F7F7A] py-3 text-[#1E2A2A] outline-none transition-all bg-transparent resize-none"
                placeholder="How can we help?"
              />
            </div>

            <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4">
              <button 
                type="button" 
                onClick={() => setFormData({
                  name: "", email: "", companyName: "", contactNumber: "",
                  productCode: "", productName: "", reason: "General Support", message: ""
                })}
                className="text-[#D32F2F] text-sm font-bold hover:underline"
              >
                Reset Form
              </button>
              
              <button 
                type="submit"
                disabled={loading}
                className={`w-full sm:w-auto px-12 py-4 bg-[#1F7F7A] hover:bg-[#155E5A] text-white font-bold rounded-full transition-all shadow-lg hover:shadow-[#1F7F7A]/20 transform hover:-translate-y-1 ${loading ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {loading ? 'Sending...' : 'Submit Enquiry'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </main>
  );
}