import Cookies from "js-cookie";
export const API_ROOT = process.env.NEXT_PUBLIC_API_ROOT;
const BASE_URL = process.env.NEXT_PUBLIC_API_URL;

// ---------- SIGNUP ----------
export const signupService = async (signupData) => {
  try {
    const res = await fetch(`${BASE_URL}/auth/signup`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(signupData),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Signup failed");
    return data;
  } catch (error) {
    throw error;
  }
};

// ---------- LOGIN ----------

export const loginService = async (loginData) => {
  try {
    const res = await fetch(`${BASE_URL}/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(loginData),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Login failed");

    // Token-ai Cookie-la store panrom (7 days expiry)
    if (data.token) {
      Cookies.set("token", data.token, {
        expires: 7,
        secure: true,
        sameSite: "strict",
      });
    }
    return data;
  } catch (error) {
    throw error;
  }
};

// ---------- GUEST LOGIN ----------

export const guestLoginService = async (guestData) => {
  try {
    const res = await fetch(`${BASE_URL}/auth/guest-login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(guestData),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Guest login failed");

    if (data.token) {
      Cookies.set("token", data.token, { expires: 1, secure: true });
    }
    return data;
  } catch (error) {
    throw error;
  }
};

// ---------- LOGOUT ----------
export const logoutService = () => {
  Cookies.remove("token");
  window.location.href = "/login"; // Full refresh for security
};

// ---------- Company profile User data----------
export const fetchUserData = async () => {
  try {
    const res = await fetch(`${BASE_URL}/auth/user-management`, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Failed to fetch User Data");
    return data;
  } catch (error) {
    throw error;
  }
};

// ---------- PRODUCT DATA----------
export const fetchProductData = async (productData) => {
  try {
    const res = await fetch(`${BASE_URL}/products`, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
      // body: JSON.stringify(productData),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Failed to fetch Products");
    return data;
  } catch (error) {
    throw error;
  }
};

// ---------- PRODUCT DATA by id----------
// ---------- FETCH SINGLE PRODUCT ----------
export const fetchProductDataById = async (id) => {
  try {
    // 1. Ensure 'id' is passed into the function
    // 2. Use backticks (`) for the URL to inject the variable
    const res = await fetch(`${BASE_URL}/products/${id}`, {
      method: "GET",
      headers: { "Content-Type": "application/json" },
    });

    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.message || `Error ${res.status}: Product not found`);
    }

    return data;
  } catch (error) {
    console.error("API Service Error:", error);
    throw error;
  }
};

// Enquiry form
export const enquiryForm = async (enquiryData) => {
  try {
    const res = await fetch(`${BASE_URL}/enquiry/submit`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(enquiryData),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Enquiry failed");
    return data;
  } catch (error) {
    throw error;
  }
};


export const fetchAddToCart = async (cartData, token) => {
  const res = await fetch(`${BASE_URL}/cart/add`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(cartData),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Failed to add to cart");
  return data;
};

export const fetchGetCart = async (token) => {
  const res = await fetch(`${BASE_URL}/cart/`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Failed to fetch cart");
  return data; // This returns the { status, data: [...] } object
};

export const fetchDeleteCart = async (id, token) => {
  const res = await fetch(`${BASE_URL}/cart/${id}`, {
    method: "DELETE",
    headers: { 
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}` 
    },
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Delete failed");
  return data;
};


export const fetchPriceEnquiry = async (priceData, token) => {
  const res = await fetch(`${BASE_URL}/priceenquiry/submit`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify(priceData),
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.message || "Failed to Submit Enquiry");
  return data;
};

// manpowerEnquiry form
export const manpowerEnquiryForm = async (enquiryData) => {
  try {
    const res = await fetch(`${BASE_URL}/enquiry/manpower-enquiry`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(enquiryData),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "ManPower Enquiry failed");
    return data;
  } catch (error) {
    throw error;
  }
};

// sparesEnquiry form
export const sparesEnquiryForm = async (enquiryData) => {
  try {
    const res = await fetch(`${BASE_URL}/enquiry/spares-enquiry`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(enquiryData),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Spares Enquiry failed");
    return data;
  } catch (error) {
    throw error;
  }
};