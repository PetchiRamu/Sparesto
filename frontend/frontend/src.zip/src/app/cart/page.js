"use client";

import Link from "next/link";
import { useState, useEffect } from "react";
import { useRouter } from "next/navigation"; 
import { Trash2, ArrowLeft, Send, Plus, Minus } from "lucide-react"; // Added Plus and Minus icons
import Cookies from 'js-cookie';
import { fetchGetCart, fetchDeleteCart, fetchPriceEnquiry } from '@/app/apiservices/apiServices';
import {API_ROOT} from "@/app/apiservices/apiServices"

export default function CartPage() {
  const router = useRouter(); 
  const [cartItems, setCartItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [address, setAddress] = useState({
    billingName: "",
    billingEmail: "",
    billingStreet: "",
    shippingStreet: "",
    isSameAsBilling: true,
  });

  useEffect(() => {
    loadCart();
  }, []);

  const loadCart = async () => {
    const token = Cookies.get('token');
    if (!token) return;
    try {
      setLoading(true);
      const response = await fetchGetCart(token);
      if (response.status === "success") setCartItems(response.data);
    } catch (error) {
      console.error("Cart fetch error:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setAddress((prev) => ({ ...prev, [name]: value }));
  };

  // --- QUANTITY CONTROLS ---
  const updateQuantity = (id, delta) => {
    setCartItems((prevItems) =>
      prevItems.map((item) => {
        if (item.id === id) {
          const newQty = Math.max(1, item.quantity + delta);
          return { ...item, quantity: newQty };
        }
        return item;
      })
    );
  };

  const handleSubmitEnquiry = async (e) => {
    e.preventDefault();
    const token = Cookies.get('token');

    if (!token) return alert("Please login first.");
    if (cartItems.length === 0) return alert("Your fleet is empty.");
    if (!address.billingName || !address.billingEmail) return alert("Fill required fields.");

    try {
      setIsSubmitting(true);
      const priceData = { cartItems, address };

      const response = await fetchPriceEnquiry(priceData, token);

      if (response.status === "success") {
        router.push('/enquiry-success'); 
        setCartItems([]);
      }
    } catch (error) {
      alert(error.message || "Submission failed");
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatImageUrl = (path) => {
    if (!path) return "https://via.placeholder.com/150";
    return `${API_ROOT}${path.replace(/\\/g, '/').replace('public/', '')}`;
  };

  const removeItem = async (id) => {
    const token = Cookies.get('token');
    try {
      await fetchDeleteCart(id, token);
      setCartItems((prev) => prev.filter((item) => item.id !== id));
    } catch (error) {
      alert("Failed to delete item");
    }
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading Fleet...</div>;

  return (
    <div className="min-h-screen bg-[#F8FAFB] pb-32 lg:pb-12" style={{ color: "#1E2A2A" }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 md:py-10">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
          <Link href="/product" className="group flex items-center gap-2 text-xs md:text-sm font-bold uppercase tracking-widest text-[#1F7F7A]">
            <ArrowLeft size={18} /> Continue Shopping
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12">
          <div className="lg:col-span-8 space-y-10">
            <div className="flex items-baseline gap-3 mb-6">
                 <h1 className="text-2xl md:text-4xl font-black tracking-tighter uppercase">MY FLEETS</h1>
                 <span className="text-base md:text-lg font-medium text-[#4FB7B0]">[{cartItems.length} units]</span>
            </div>
            
            <div className="space-y-4 md:space-y-6">
              {cartItems.map((item) => (
                <div key={item.id} className="relative rounded-2xl md:rounded-3xl border bg-white p-4 md:p-8 hover:shadow-lg transition-all" style={{ borderColor: "#D6ECEA" }}>
                  <div className="flex flex-col sm:flex-row gap-4 md:gap-8 items-center">
                    <div className="w-24 h-24 md:w-32 md:h-32 bg-[#AEEBE7] rounded-xl flex-shrink-0 overflow-hidden p-1 shadow-inner">
                      <img src={formatImageUrl(item.product?.image)} alt={item.product?.name} className="w-full h-full object-cover rounded-lg bg-white" />
                    </div>
                    <div className="flex-1 w-full">
                      <div className="flex justify-between items-start">
                        <div>
                          <h3 className="font-bold text-lg md:text-xl">{item.product?.name}</h3>
                          <span className="text-[10px] font-mono px-2 py-1 rounded-full border border-[#D6ECEA] text-[#5F6F73]">ID: {item.productId}</span>
                        </div>
                        <button onClick={() => removeItem(item.id)} className="p-2 hover:bg-red-50 rounded-lg">
                          <Trash2 size={18} className="text-red-500" />
                        </button>
                      </div>
                      <div className="flex justify-between items-center pt-4 mt-4 border-t border-dashed border-[#D6ECEA]">
                        <div>
                          <p className="text-xs font-bold text-gray-400 mb-1">QUANTITY</p>
                          <div className="flex items-center gap-3 bg-gray-50 p-1 px-2 rounded-xl border border-[#D6ECEA]">
                            <button 
                              onClick={() => updateQuantity(item.id, -1)}
                              className="w-8 h-8 flex items-center justify-center bg-white border rounded-lg hover:bg-red-50 hover:text-red-500 transition-colors"
                            >
                              <Minus size={14} />
                            </button>
                            <span className="text-lg font-black min-w-[20px] text-center">{item.quantity}</span>
                            <button 
                              onClick={() => updateQuantity(item.id, 1)}
                              className="w-8 h-8 flex items-center justify-center bg-white border rounded-lg hover:bg-[#1F7F7A] hover:text-white transition-colors"
                            >
                              <Plus size={14} />
                            </button>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-xs font-bold text-gray-400">LEAD TIME</p>
                          <p className="text-sm font-bold italic">{item.product?.leadTime}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className="bg-white p-6 md:p-8 rounded-3xl border" style={{ borderColor: "#D6ECEA" }}>
                  <h2 className="font-black uppercase text-lg mb-6 border-b pb-4 text-[#1E2A2A]">Billing Details</h2>
                  <div className="space-y-4">
                    <input type="text" name="billingName" value={address.billingName} placeholder="Full Name" className="w-full p-3 rounded-xl border bg-gray-50 text-sm focus:ring-2 focus:ring-[#1F7F7A] outline-none" onChange={handleInputChange} />
                    <input type="email" name="billingEmail" value={address.billingEmail} placeholder="Email Address" className="w-full p-3 rounded-xl border bg-gray-50 text-sm focus:ring-2 focus:ring-[#1F7F7A] outline-none" onChange={handleInputChange} />
                    <textarea name="billingStreet" value={address.billingStreet} placeholder="Address" className="w-full p-3 rounded-xl border bg-gray-50 text-sm min-h-[100px] focus:ring-2 focus:ring-[#1F7F7A] outline-none" onChange={handleInputChange}></textarea>
                  </div>
               </div>
               <div className="bg-white p-6 md:p-8 rounded-3xl border" style={{ borderColor: "#D6ECEA" }}>
                  <h2 className="font-black uppercase text-lg mb-6 border-b pb-4 text-[#1E2A2A]">Shipping Details</h2>
                  <div className="flex items-center gap-2 mb-4">
                    <input type="checkbox" id="sameAsBilling" checked={address.isSameAsBilling} onChange={(e) => setAddress({...address, isSameAsBilling: e.target.checked})} className="accent-[#1F7F7A] w-4 h-4" />
                    <label htmlFor="sameAsBilling" className="text-xs font-bold text-gray-500 uppercase cursor-pointer">Same as Billing</label>
                  </div>
                  <textarea name="shippingStreet" value={address.isSameAsBilling ? address.billingStreet : address.shippingStreet} disabled={address.isSameAsBilling} placeholder="Shipping Address" className="w-full p-3 rounded-xl border bg-gray-50 text-sm min-h-[145px] focus:ring-2 focus:ring-[#1F7F7A] outline-none" onChange={handleInputChange}></textarea>
               </div>
            </div>
          </div>

          <div className="lg:col-span-4">
            <div className="lg:sticky lg:top-10 rounded-[2.5rem] border-4 bg-white p-8 shadow-xl border-[#AEEBE7]">
              <h2 className="text-2xl font-black mb-6 italic uppercase tracking-tighter border-b-4 border-[#4FB7B0] pb-2 inline-block text-[#1E2A2A]">Request Quote</h2>
              <button 
                onClick={handleSubmitEnquiry} 
                disabled={isSubmitting || cartItems.length === 0}
                className={`w-full py-6 rounded-2xl font-black text-xl text-white shadow-lg flex items-center justify-center gap-2 transition-all ${isSubmitting ? 'bg-gray-400 cursor-not-allowed' : 'bg-[#1F7F7A] hover:brightness-110 active:scale-95'}`}
              >
                {isSubmitting ? "SENDING..." : "SUBMIT ENQUIRY"} <Send size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}



