// 'use client';
// import React, { useState } from 'react';
// // import { manpowerEnquiryForm } from '@/services/apiServices'; 
// import { manpowerEnquiryForm } from '@/app/apiservices/apiServices';

// export default function ManpowerServicesPage() {
//   const [formData, setFormData] = useState({
//     fullName: '',
//     email: '',
//     message: ''
//   });
//   const [loading, setLoading] = useState(false);
//   const [status, setStatus] = useState({ type: '', msg: '' });

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setLoading(true);
//     setStatus({ type: '', msg: '' });

//     try {
//       const enquiryData = {
//         fullName: formData.fullName, 
//         email: formData.email,
//         service: "Manpower Services", // Fixed value
//         message: formData.message,
//       };

//       await manpowerEnquiryForm(enquiryData);
//       setStatus({ type: 'success', msg: 'Request sent successfully!' });
//       setFormData({ fullName: '', email: '', message: '' });
//     } catch (error) {
//       setStatus({ type: 'error', msg: error.message || 'Something went wrong.' });
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="min-h-screen bg-[#F7FAFA] font-['Inter',_sans-serif] py-12 px-4 text-[#1E2A2A]">
//       <div className="max-w-5xl mx-auto">
        
//         {/* Header Section */}
//         <header className="mb-10 text-center md:text-left">
//           <span className="inline-block bg-[#4FB7B0] text-white text-[13px] font-semibold px-3 py-1 rounded mb-4 tracking-wide">
//             5000+ spare parts & critical components
//           </span>
//           <h1 className="text-[32px] md:text-[40px] font-bold text-[#1F7F7A] leading-tight tracking-[0.3px]">
//             Manpower Services
//           </h1>
//         </header>

//         <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
//           {/* Left Side: About Content */}
//           <div className="lg:col-span-2 space-y-6">
//             <main className="bg-white rounded-[10px] border border-[#D6ECEA] p-8 shadow-[0px_4px_12px_rgba(0,0,0,0.06)]">
//               <h2 className="text-[24px] font-semibold text-[#155E5A] mb-6 pb-2 border-b-2 border-[#D6ECEA]">
//                 About us
//               </h2>
              
//               <div className="space-y-6 text-[#5F6F73] text-[16px] leading-[1.5] tracking-[0.3px]">
//                 <p>
//                   <span className="font-semibold text-[#1F7F7A]">Connected Wind Services</span> is Denmark's leading independent service provider within wind turbine service and repair.
//                 </p>

//                 <p>
//                   We have been working within the wind turbine industry since <span className="font-semibold text-[#1F7F7A]">1987</span> and today perform service on more than <span className="font-semibold text-[#1F7F7A]">1000</span> turbines in Denmark.
//                 </p>

//                 <p>
//                   Connected Wind Services is the ISP with the <span className="font-semibold text-[#1F7F7A]">largest components and spare parts inventory</span> in the market. With thousands of spare parts of highest quality in stock, Connected Wind Services can provide almost any component and spare part needed by wind farms throughout the world.
//                 </p>

//                 <p>
//                   Strong ties to key wind turbine OEMs, equipment OEMs and sub-suppliers further improves our ability to identify, source and supply the parts you need efficiently.
//                 </p>
//               </div>

//               <div className="mt-8">
//                 <a 
//                   href="#" 
//                   className="inline-block bg-white border border-[#1F7F7A] text-[#1F7F7A] hover:bg-[#E6F4F3] font-semibold py-2.5 px-6 rounded-[8px] text-[14px] transition-colors duration-200"
//                 >
//                   Read more about us here
//                 </a>
//               </div>
//             </main>
//           </div>

//           {/* Right Side: Request Quote Form */}
//           <aside className="lg:col-span-1">
//             <div className="bg-white rounded-[10px] border border-[#D6ECEA] p-6 shadow-[0px_4px_12px_rgba(0,0,0,0.06)] sticky top-6">
//               <h3 className="text-[20px] font-semibold text-[#1F7F7A] mb-1">Request a Quote</h3>
//               <p className="text-[13px] text-[#5F6F73] mb-6">Expert consultation for your wind farm.</p>
              
//               <form className="space-y-4" onSubmit={handleSubmit}>
//                 <div>
//                   <label className="block text-[12px] font-semibold text-[#5F6F73] uppercase mb-1">Full Name</label>
//                   <input 
//                     type="text" 
//                     name="fullName"
//                     required
//                     value={formData.fullName}
//                     onChange={handleChange}
//                     className="w-full bg-[#F7FAFA] border border-[#D6ECEA] rounded-[8px] px-4 py-2 text-[14px] focus:outline-none focus:border-[#1F7F7A] transition-colors"
//                     placeholder="John Doe"
//                   />
//                 </div>

//                 <div>
//                   <label className="block text-[12px] font-semibold text-[#5F6F73] uppercase mb-1">Work Email</label>
//                   <input 
//                     type="email" 
//                     name="email"
//                     required
//                     value={formData.email}
//                     onChange={handleChange}
//                     className="w-full bg-[#F7FAFA] border border-[#D6ECEA] rounded-[8px] px-4 py-2 text-[14px] focus:outline-none focus:border-[#1F7F7A] transition-colors"
//                     placeholder="john@company.com"
//                   />
//                 </div>

//                 {/* Service Type - Displayed as static text instead of a dropdown */}
//                 <div>
//                   <label className="block text-[12px] font-semibold text-[#5F6F73] uppercase mb-1">Service Type</label>
//                   <div className="w-full bg-[#E6F4F3] border border-[#D6ECEA] rounded-[8px] px-4 py-2 text-[14px] text-[#1F7F7A] font-medium">
//                     Manpower Services
//                   </div>
//                 </div>

//                 <div>
//                   <label className="block text-[12px] font-semibold text-[#5F6F73] uppercase mb-1">Message</label>
//                   <textarea 
//                     rows="4"
//                     name="message"
//                     required
//                     value={formData.message}
//                     onChange={handleChange}
//                     className="w-full bg-[#F7FAFA] border border-[#D6ECEA] rounded-[8px] px-4 py-2 text-[14px] focus:outline-none focus:border-[#1F7F7A] transition-colors"
//                     placeholder="Describe your requirements..."
//                   ></textarea>
//                 </div>

//                 {status.msg && (
//                   <div className={`text-[13px] font-medium ${status.type === 'success' ? 'text-green-600' : 'text-red-600'}`}>
//                     {status.msg}
//                   </div>
//                 )}

//                 <button 
//                   type="submit"
//                   disabled={loading}
//                   className={`w-full bg-[#1F7F7A] hover:bg-[#155E5A] text-white font-semibold py-3 rounded-[8px] text-[14px] transition-all duration-200 shadow-sm ${loading ? 'opacity-70 cursor-not-allowed' : ''}`}
//                 >
//                   {loading ? 'Sending...' : 'Send Request'}
//                 </button>
//               </form>
//             </div>
//           </aside>

//         </div>
//       </div>
//     </div>
//   );
// }


'use client';
import React, { useState } from 'react';
import { manpowerEnquiryForm } from '@/app/apiservices/apiServices';

export default function ManpowerServicesPage() {
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    message: ''
  });
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState({ type: '', msg: '' });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus({ type: '', msg: '' });

    try {
      const enquiryData = {
        fullName: formData.fullName, 
        email: formData.email,
        service: "Manpower Services", // Fixed value
        message: formData.message,
      };

      await manpowerEnquiryForm(enquiryData);
      setStatus({ type: 'success', msg: 'Request sent successfully!' });
      setFormData({ fullName: '', email: '', message: '' });
      setTimeout(() => setStatus({ type: '', msg: '' }), 5000);
    } catch (error) {
      setStatus({ type: 'error', msg: error.message || 'Something went wrong.' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F7FAFA] font-['Inter',_sans-serif] text-[#1E2A2A]">
      
      {/* 1. HERO SECTION */}
      <section className="bg-gradient-to-r from-[#1F7F7A] to-[#155E5A] py-16 px-4 text-white">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-8 items-center">
          <div>
            <span className="bg-[#4FB7B0] text-[12px] font-bold px-3 py-1 rounded-full uppercase tracking-wider">
              Technical Excellence
            </span>
            <h1 className="text-4xl md:text-5xl font-bold mt-4 leading-tight">
              Expert Wind Turbine <br/> Manpower Services
            </h1>
            <p className="mt-6 text-emerald-50 text-lg max-w-lg">
              Access highly skilled technicians and engineers. 
              We are Denmark's leading independent service provider since 1987.
            </p>
          </div>
          <div className="hidden md:block">
            <img 
              src="https://images.unsplash.com/photo-1466611653911-95081537e5b7?q=80&w=1000&auto=format&fit=crop" 
              alt="Technician working on turbine" 
              className="rounded-2xl shadow-2xl border-4 border-white/10"
            />
          </div>
        </div>
      </section>

      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          
          {/* 2. LEFT SIDE: CONTENT & STATS */}
          <div className="lg:col-span-2 space-y-10">
            
            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {[
                { label: 'Established', val: '1987' },
                { label: 'Technicians', val: '200+' },
                { label: 'Turbines Served', val: '1,000+' }
              ].map((stat, i) => (
                <div key={i} className="bg-white p-6 rounded-xl border border-[#D6ECEA] shadow-sm text-center">
                  <p className="text-[#1F7F7A] text-2xl font-bold">{stat.val}</p>
                  <p className="text-[#5F6F73] text-sm">{stat.label}</p>
                </div>
              ))}
            </div>

            <main className="prose prose-slate max-w-none">
              <h2 className="text-2xl font-bold text-[#155E5A] flex items-center gap-2">
                About Our Expertise
              </h2>
              
              <div className="space-y-6 text-[#5F6F73] text-lg leading-relaxed">
                <p>
                  <strong className="text-[#1F7F7A]">Connected Wind Services</strong> is Denmark's leading independent service provider within wind turbine service and repair.
                </p>
                
                <p>
                  We have been working within the wind turbine industry since <strong>1987</strong> and today perform service on more than <strong>1,000</strong> turbines in Denmark. Our technical teams are trained to handle complex maintenance, upgrades, and emergency repairs across multiple OEM platforms.
                </p>

                

                <div className="grid md:grid-cols-2 gap-6 mt-8">
                  <div className="bg-[#E6F4F3] p-5 rounded-lg border-l-4 border-[#1F7F7A]">
                    <h4 className="font-bold text-[#155E5A] mb-2">Qualified Teams</h4>
                    <p className="text-sm">GWO certified technicians with extensive experience in mechanical and electrical systems.</p>
                  </div>
                  <div className="bg-[#E6F4F3] p-5 rounded-lg border-l-4 border-[#1F7F7A]">
                    <h4 className="font-bold text-[#155E5A] mb-2">Largest Inventory</h4>
                    <p className="text-sm">Supported by the ISP with the largest components inventory to ensure rapid repair cycles.</p>
                  </div>
                </div>
              </div>
              
              <div className="mt-10">
                <a 
                  href="#" 
                  className="inline-block bg-white border border-[#1F7F7A] text-[#1F7F7A] hover:bg-[#E6F4F3] font-bold py-3 px-8 rounded-lg text-sm transition-all"
                >
                  Read more about us here
                </a>
              </div>
            </main>
          </div>

          {/* 3. RIGHT SIDE: STICKY FORM */}
          <aside className="lg:col-span-1">
            <div className="bg-white rounded-2xl border border-[#D6ECEA] p-8 shadow-xl sticky top-8">
              <div className="mb-6">
                <h3 className="text-2xl font-bold text-[#1F7F7A]">Request a Quote</h3>
                <p className="text-sm text-[#5F6F73] mt-1">Expert consultation for your wind farm.</p>
              </div>
              
              <form className="space-y-5" onSubmit={handleSubmit}>
                {status.msg && (
                  <div className={`px-4 py-3 rounded-lg text-sm border ${
                    status.type === 'success' 
                      ? 'bg-green-50 border-green-200 text-green-700 animate-pulse' 
                      : 'bg-red-50 border-red-200 text-red-600'
                  }`}>
                    {status.type === 'success' && '✓ '}{status.msg}
                  </div>
                )}

                <div>
                  <label className="block text-xs font-bold text-[#5F6F73] uppercase mb-1.5 ml-1">Full Name</label>
                  <input 
                    type="text" name="fullName" value={formData.fullName} onChange={handleChange} required
                    className="w-full bg-[#F7FAFA] border border-[#D6ECEA] rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-[#1F7F7A] outline-none transition-all"
                    placeholder="John Doe"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#5F6F73] uppercase mb-1.5 ml-1">Work Email</label>
                  <input 
                    type="email" name="email" value={formData.email} onChange={handleChange} required
                    className="w-full bg-[#F7FAFA] border border-[#D6ECEA] rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-[#1F7F7A] outline-none transition-all"
                    placeholder="john@company.com"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#5F6F73] uppercase mb-1.5 ml-1">Service Type</label>
                  <input 
                    type="text" 
                    value="Manpower Services" 
                    readOnly 
                    className="w-full bg-gray-100 border border-[#D6ECEA] rounded-lg px-4 py-3 text-sm text-[#5F6F73] cursor-not-allowed outline-none font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-[#5F6F73] uppercase mb-1.5 ml-1">Message</label>
                  <textarea 
                    name="message" value={formData.message} onChange={handleChange} rows="4" required
                    className="w-full bg-[#F7FAFA] border border-[#D6ECEA] rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-[#1F7F7A] outline-none transition-all"
                    placeholder="Describe your requirements..."
                  ></textarea>
                </div>

                <button 
                  type="submit" disabled={loading}
                  className={`w-full py-4 rounded-lg font-bold text-white transition-all transform active:scale-[0.98] shadow-lg ${
                    loading ? 'bg-gray-400' : 'bg-[#1F7F7A] hover:bg-[#155E5A] hover:shadow-[#1F7F7A]/20'
                  }`}
                >
                  {loading ? 'Sending...' : 'Send Request'}
                </button>
              </form>
            </div>
          </aside>

        </div>
      </div>
    </div>
  );
}