// 'use client';
// import React, { useState } from 'react';
// import Header from '../components/header';
// import Footer from '../components/footer';

// export default function ContactUs() {
//   const [formData, setFormData] = useState({
//     name: '',
//     email: '',
//     subject: '',
//     message: '',
//   });

//   const handleChange = (e) => {
//     setFormData({ ...formData, [e.target.name]: e.target.value });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     // For now, just log data
//     console.log(formData);
//     alert('Message sent! We will get back to you soon.');
//     setFormData({ name: '', email: '', subject: '', message: '' });
//   };

//   return (
//     <div>
//       <Header />
//       <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
//         <div className="max-w-3xl w-full bg-white shadow-lg rounded-lg p-8 sm:p-12">
//           <h2 className="text-3xl font-bold text-gray-900 mb-6 text-center">
//             Contact Us
//           </h2>
//           <p className="text-gray-600 text-center mb-8">
//             Have questions or feedback? Send us a message and we’ll get back to you shortly.
//           </p>

//           <form onSubmit={handleSubmit} className="space-y-6">
//             <div>
//               <label htmlFor="name" className="block text-sm font-medium text-gray-700">
//                 Name
//               </label>
//               <input
//                 type="text"
//                 name="name"
//                 id="name"
//                 value={formData.name}
//                 onChange={handleChange}
//                 required
//                 className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2"
//               />
//             </div>

//             <div>
//               <label htmlFor="email" className="block text-sm font-medium text-gray-700">
//                 Email
//               </label>
//               <input
//                 type="email"
//                 name="email"
//                 id="email"
//                 value={formData.email}
//                 onChange={handleChange}
//                 required
//                 className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2"
//               />
//             </div>

//             <div>
//               <label htmlFor="subject" className="block text-sm font-medium text-gray-700">
//                 Subject
//               </label>
//               <input
//                 type="text"
//                 name="subject"
//                 id="subject"
//                 value={formData.subject}
//                 onChange={handleChange}
//                 required
//                 className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2"
//               />
//             </div>

//             <div>
//               <label htmlFor="message" className="block text-sm font-medium text-gray-700">
//                 Message
//               </label>
//               <textarea
//                 name="message"
//                 id="message"
//                 rows="5"
//                 value={formData.message}
//                 onChange={handleChange}
//                 required
//                 className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-2"
//               ></textarea>
//             </div>

//             <div className="text-center">
//               <button
//                 type="submit"
//                 className="inline-flex justify-center py-2 px-6 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition"
//               >
//                 Send Message
//               </button>
//             </div>
//           </form>
//         </div>
//       </div>
//       <Footer />
//     </div>
//   );
// }




'use client';
import React, { useState } from 'react';
import Header from '../components/header';
import Footer from '../components/footer';
import Image from 'next/image';

export default function ContactUs() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: '',
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
    alert('Message sent! We will get back to you soon.');
    setFormData({ name: '', email: '', subject: '', message: '' });
  };

  return (
    <div className="flex flex-col min-h-screen">
      <Header />

      <div className="flex-grow bg-gradient-to-r from-indigo-50 to-indigo-100 py-16 px-4 sm:px-6 lg:px-20">
        <div className="max-w-7xl mx-auto grid lg:grid-cols-2 gap-12 items-center">
          
          {/* Left - Contact Form */}
          <div className="bg-white rounded-2xl shadow-xl p-8 sm:p-12">
            <h2 className="text-4xl font-bold text-gray-900 mb-4 text-center lg:text-left">
              Get in Touch
            </h2>
            <p className="text-gray-600 mb-8 text-center lg:text-left">
              Have questions or feedback? Fill out the form and we’ll get back to you shortly.
            </p>

            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">
                  Name
                </label>
                <input
                  type="text"
                  name="name"
                  id="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-3"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                  Email
                </label>
                <input
                  type="email"
                  name="email"
                  id="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-3"
                />
              </div>

              <div>
                <label htmlFor="subject" className="block text-sm font-medium text-gray-700">
                  Subject
                </label>
                <input
                  type="text"
                  name="subject"
                  id="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-3"
                />
              </div>

              <div>
                <label htmlFor="message" className="block text-sm font-medium text-gray-700">
                  Message
                </label>
                <textarea
                  name="message"
                  id="message"
                  rows="5"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  className="mt-1 block w-full rounded-lg border-gray-300 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm p-3"
                ></textarea>
              </div>

              <div className="text-center lg:text-left">
                <button
                  type="submit"
                  className="w-full lg:w-auto inline-flex justify-center py-3 px-8 border border-transparent shadow-sm text-sm font-medium rounded-lg text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 transition"
                >
                  Send Message
                </button>
              </div>
            </form>
          </div>

          {/* Right - Image / Info */}
          <div className="flex flex-col justify-center items-center lg:items-start space-y-6">
            <Image
              src="/contact-illustration.svg"
              alt="Contact Us Illustration"
              width={400}
              height={400}
              className="w-full max-w-md"
            />
            <div className="text-center lg:text-left">
              <h3 className="text-2xl font-semibold text-gray-900 mb-2">Our Office</h3>
              <p className="text-gray-600">
                123 Main Street, <br />
                Your City, Your Country <br />
                Email: support@example.com <br />
                Phone: +123 456 7890
              </p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
