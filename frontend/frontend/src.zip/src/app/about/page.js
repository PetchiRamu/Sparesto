import Header from "../components/header";

export default function AboutPage() {
  return (
    <section className="w-full bg-[#fafafa] min-h-screen">
      <Header />
      <div className="max-w-7xl mx-auto px-6 py-10 md:py-20">
        
        {/* Header - Left Aligned */}
        <div className="mb-12 md:mb-16 max-w-2xl">
          <span className="text-[#1f807b] font-bold tracking-widest uppercase text-sm">Our Legacy</span>
          <h2 className="text-3xl md:text-5xl font-black text-slate-900 mt-2 leading-tight">
            Powering the wind industry through resourcefulness.
          </h2>
        </div>

        {/* Bento Grid Container */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          
          {/* Large Main Card - Spans 2 columns on Large screens */}
          <div className="lg:col-span-2 bg-white p-8 md:p-10 rounded-[32px] border border-slate-200 shadow-sm flex flex-col justify-between min-h-[300px]">
            <div>
              <h3 className="text-2xl font-bold mb-4 text-slate-900">Know Our Team</h3>
              <p className="text-slate-600 leading-relaxed text-lg">
                Spares in Motion has provided aftermarket wind turbine solutions for over a decade. 
                We understand that in the energy sector, <strong className="text-slate-900">reliability isn't optional—it's mandatory.</strong>
              </p>
            </div>
            <div className="mt-8 flex flex-wrap gap-3">
               <div className="px-4 py-2 bg-blue-50 text-[#1f807b] rounded-full text-xs md:text-sm font-semibold border border-blue-100">10+ Years Experience</div>
               <div className="px-4 py-2 bg-green-50 text-green-700 rounded-full text-xs md:text-sm font-semibold border border-green-100">Global Network</div>
            </div>
          </div>

          {/* Small Feature Card - Resourceful */}
          <div className="bg-[#1f807b] p-8 rounded-[32px] text-white flex flex-col justify-center min-h-[220px] lg:min-h-full">
            <h4 className="text-xl font-bold mb-2">Resourceful</h4>
            <p className="opacity-90">Our workforce is characterized by high creativity in solving complex logistics.</p>
          </div>

          {/* Small Feature Card - Diversity */}
          <div className="bg-[#1f807b] p-8 rounded-[32px] text-white flex flex-col justify-center min-h-[220px] lg:min-h-full">
            <h4 className="text-xl font-bold mb-2">Diverse Culture</h4>
            <p className="opacity-90">Integrating multiple languages and cultures to serve every continent.</p>
          </div>

          {/* Long Horizontal Card - Spans 2 columns on Large screens */}
          <div className="lg:col-span-2 bg-white p-8 md:p-10 rounded-[32px] border border-slate-200 shadow-sm flex flex-col justify-center min-h-[200px]">
             <h3 className="text-xl font-bold mb-4 text-slate-900">Sustainable Focus</h3>
             <p className="text-slate-600 leading-relaxed">
                By improving the use of existing resources, we reduce waste in the wind supply chain. 
                Our activities rely on a dependable network of suppliers committed to a greener future.
             </p>
          </div>
        </div>

        {/* Tagline CTA */}
        <div className="mt-16 md:mt-24 text-center">
          <h3 className="text-2xl md:text-4xl font-bold italic text-slate-400 px-4">
            "Come for the parts, <span className="text-slate-900 block md:inline">stay for the service!</span>"
          </h3>
          <button className="mt-8 bg-[#1f807b] hover:scale-105 active:scale-95 transition-all text-white px-10 py-4 rounded-full font-bold shadow-lg shadow-teal-100/50">
            Get in Touch
          </button>
        </div>

      </div>
    </section>
  );
}