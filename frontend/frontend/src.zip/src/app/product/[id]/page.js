'use client';
import React, { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation'; 
import Header from "@/app/components/header";
import { fetchProductDataById, fetchAddToCart, API_ROOT } from '@/app/apiservices/apiServices';
import Cookies from 'js-cookie';

// Swiper Imports
import { Swiper, SwiperSlide } from 'swiper/react';
import { Navigation, Pagination, Autoplay } from 'swiper/modules';

// Swiper Styles
import 'swiper/css';
import 'swiper/css/navigation';
import 'swiper/css/pagination';
import { ApiError } from 'next/dist/server/api-utils';

const ProductDetailPage = () => {
  const params = useParams();
  const router = useRouter();
  const id = params?.id;

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isAdding, setIsAdding] = useState(false);

  useEffect(() => {
    const checkAuth = () => {
      const token = Cookies.get('token');
      setIsLoggedIn(!!token);
    };

    const getSingleProduct = async () => {
      if (!id) return;
      try {
        setLoading(true);
        const data = await fetchProductDataById(id);
        const productData = Array.isArray(data) ? data[0] : data;
        
        if (!productData || Object.keys(productData).length === 0) {
          throw new Error("Product data is empty");
        }
        setProduct(productData);
      } catch (err) {
        setError(`Failed to load product details: ${err.message}`);
      } finally {
        setLoading(false);
      }
    };

    checkAuth();
    getSingleProduct();
  }, [id]);

  // ADD TO CART FUNCTIONALITY
  const handleAddToCart = async () => {
    const token = Cookies.get('token');
    
    if (!token) {
      alert("Your session might have expired. Please login again.");
      router.push('/login');
      return;
    }

    try {
      setIsAdding(true);
      const cartPayload = {
        productId: product.id,
        quantity: product.moq || 1
      };

      await fetchAddToCart(cartPayload, token);
      router.push('/cart'); 
    } catch (err) {
      console.error("Add to cart error:", err);
      if (err.message.toLowerCase().includes("token")) {
        alert("Invalid or expired session. Please login again.");
        router.push('/login');
      } else {
        alert(err.message || "Failed to add to cart");
      }
    } finally {
      setIsAdding(false);
    }
  };

  // Helper function to format image URLs
  const formatImageUrl = (path) => {
    if (!path) return null;
    return `${API_ROOT}${path.replace(/\\/g, '/').replace('public/', '')}`;
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1F7F7A]"></div>
    </div>
  );

  if (error) return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-4">
      <div className="bg-white p-8 rounded-xl shadow-md text-center">
        <p className="text-red-500 font-bold mb-4">{error}</p>
        <button onClick={() => window.location.reload()} className="px-6 py-2 bg-[#1F7F7A] text-white rounded-lg">Try Again</button>
      </div>
    </div>
  );

  if (!product) return null;

  // Determine if we have multiple images or just one
  const imagesToShow = product.images && Array.isArray(product.images) && product.images.length > 0 
    ? product.images 
    : product.image ? [product.image] : [];

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      <Header/>  
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 text-sm text-gray-500">
        <a href="/" className="hover:text-[#1F7F7A]">Home</a> / 
        <span className="font-medium text-gray-700 ml-1">{product.name}</span>
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Product Image Slider Section */}
          <div className="lg:col-span-2">
            <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm relative group">
              {imagesToShow.length > 0 ? (
                <Swiper
                  modules={[Navigation, Pagination, Autoplay]}
                  navigation={imagesToShow.length > 1}
                  pagination={{ clickable: true }}
                  autoplay={{ delay: 3000, disableOnInteraction: false }}
                  className="w-full aspect-video md:aspect-[16/9]"
                >
                  {imagesToShow.map((img, index) => (
                    <SwiperSlide key={index} className="flex items-center justify-center bg-white">
                      <img 
                        src={formatImageUrl(img)} 
                        alt={`${product.name} - ${index + 1}`} 
                        className="w-full h-full object-contain p-4"
                        onError={(e) => { e.target.src = "https://via.placeholder.com/600x400?text=Image+Not+Found"; }}
                      />
                    </SwiperSlide>
                  ))}
                </Swiper>
              ) : (
                <div className="aspect-video flex items-center justify-center text-gray-400 bg-gray-100">
                  No Image Available
                </div>
              )}
            </div>

            {/* Detailed Specifications */}
            <div className="mt-8 bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
              <h2 className="text-xl font-bold text-gray-800 mb-4">Detailed Specifications</h2>
              {isLoggedIn ? (
                <div className="prose prose-sm max-w-none text-gray-600">
                  {product.detailedSpecs || "No detailed specifications provided."}
                </div>
              ) : (
                <div className="bg-gray-50 p-4 rounded-lg border border-dashed border-gray-300 text-center">
                   <p className="text-gray-500 italic">Please login to view full technical specifications.</p>
                </div>
              )}
            </div>
          </div>

          {/* Pricing and Details Logic */}
          <div className="lg:col-span-1 space-y-6">
            <div className="space-y-4">
              <h1 className="text-3xl font-bold text-gray-900">{product.name}</h1>
              
              <div className="flex flex-wrap gap-2">
                {product.packOption && (
                  <span className="px-3 py-1 bg-gray-100 text-gray-700 text-xs font-semibold rounded-full border border-gray-200">
                    {product.packOption}
                  </span>
                )}
                <span className="px-3 py-1 bg-blue-50 text-blue-700 text-xs font-semibold rounded-full border border-blue-100">
                  MOQ: {product.moq || 1}
                </span>
              </div>

              {product.relatedSkus && product.relatedSkus.length > 0 && (
                <div className="pt-2">
                  <p className="text-xs font-bold text-gray-400 uppercase mb-2">Related SKUs</p>
                  <div className="flex flex-wrap gap-2">
                    {product.relatedSkus.map((sku, index) => (
                      <span key={index} className="px-2 py-1 bg-white border border-gray-300 text-gray-600 text-[10px] font-mono rounded">
                        {sku}
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {isLoggedIn ? (
              <>
                <div className="bg-white border border-gray-200 rounded-xl p-5 shadow-sm space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Available Stock</p>
                      <p className={`text-lg font-bold ${product.availableStock > 0 ? 'text-green-600' : 'text-red-500'}`}>
                        {product.availableStock > 0 ? `${product.availableStock} Units` : 'Out of Stock'}
                      </p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Lead Time</p>
                      <p className="text-lg font-bold text-gray-800">{product.leadTime || 'N/A'}</p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4 bg-white p-5 border border-gray-200 rounded-xl shadow-sm">
                  <button 
                    onClick={handleAddToCart}
                    disabled={product.availableStock <= 0 || isAdding}
                    className={`w-full py-3 rounded-lg font-bold transition-all shadow-md ${
                      product.availableStock > 0 && !isAdding
                      ? 'bg-[#155E5A] hover:bg-[#1F7F7A] text-white' 
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                    }`}
                  >
                    {isAdding ? 'Adding...' : product.availableStock > 0 ? 'Add to Cart' : 'Out of Stock'}
                  </button>
                </div>
              </>
            ) : (
              <div className="bg-white border-2 border-dashed border-[#1F7F7A] rounded-xl p-8 text-center space-y-4">
                <h3 className="font-bold text-gray-800">Exclusive Wholesale Rates</h3>
                <p className="text-sm text-gray-500">Sign up or Login to see our tiered pricing and order documentation.</p>
                <button 
                  onClick={() => router.push('/login')}
                  className="w-full py-3 bg-[#1F7F7A] text-white rounded-lg font-bold hover:bg-[#155E5A] transition-colors"
                >
                  Login to View Price
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Documentation Section */}
        {isLoggedIn && product.technicalSheets && product.technicalSheets.length > 0 && (
          <div className="mt-12 border-t pt-10">
            <h2 className="text-xl font-bold text-gray-800 mb-6">Product Documentation</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {product.technicalSheets.map((sheet, idx) => (
                  <div key={idx} className="flex items-center justify-between p-4 bg-white border border-gray-200 rounded-xl shadow-sm hover:border-[#1F7F7A] transition-colors group">
                    <div className="flex items-center space-x-3">
                        <span className="text-sm font-semibold text-gray-700">Technical Sheet {idx + 1}</span>
                    </div>
                    <a 
                      href={`${API_ROOT}${sheet.replace(/\\/g, '/').replace('public/', '')}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-[#1F7F7A] font-bold text-xs border border-[#1F7F7A]/20 bg-[#1F7F7A]/5 px-3 py-1.5 rounded hover:bg-[#1F7F7A] hover:text-white transition-all"
                    >
                      VIEW PDF
                    </a>
                  </div>
                ))}
            </div>
          </div>
        )}
      </main>
      
      {/* Swiper Arrow Style Fix */}
      <style jsx global>{`
        .swiper-button-next, .swiper-button-prev {
          color: #1F7F7A !important;
          background: white;
          width: 40px !important;
          height: 40px !important;
          border-radius: 50%;
          box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1);
        }
        .swiper-button-next:after, .swiper-button-prev:after {
          font-size: 18px !important;
          font-weight: bold;
        }
        .swiper-pagination-bullet-active {
          background: #1F7F7A !important;
        }
      `}</style>
    </div>
  );
};

export default ProductDetailPage;